package com.topcoder.util.errorhandling.functionaltests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>This test case aggregates all functional test cases.</p>
 *
 * @author TopCoder Software
 * @version 1.0
 */
public class FunctionalTests extends TestCase {

    public static Test suite() {
        final TestSuite suite = new TestSuite();
        suite.addTest(CreateExceptionErrorTestCase.suite());
        suite.addTest(GetCauseTestCase.suite());
        suite.addTest(GetMessageTestCase.suite());
        suite.addTest(PrintStackTraceTestCase.suite());
        return suite;
    }

}

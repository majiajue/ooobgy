package com.topcoder.util.errorhandling.stresstests;

import java.util.Hashtable;
import junit.framework.TestCase;
import com.topcoder.util.errorhandling.*;
import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * <p>This test launches a number of threads each accessing their own 
 * BaseException.</p>
 *
 * @author aksonov
 * @version 1.0
 */
public class BaseExceptionConcurrency extends AbstractBenchmark {

    private static final int CHAIN_LENGTH = 200;
    private static final int NUM_THREADS = 100;

    public BaseExceptionConcurrency(){
        super("BaseExceptionConcurrency");
    }

    /**
     * <p>This test launches a number of threads each creating long chain 
     * contained from BaseException objects.</p>
     *
     * @exception InterruptedException if the test is interrupted
     */
    public void testBaseExceptionConcurrency()  throws Exception{
        runBenchmark(10, "BaseException");
    }

    public void runOnce() throws InterruptedException {
        BaseExceptionTester[] threads = new BaseExceptionTester[NUM_THREADS];
        for (int i = 0; i < threads.length; ++i) {
            threads[i] = new BaseExceptionTester();
            threads[i].start();
        }
        for (int i = 0; i < threads.length; ++i) {
            threads[i].join();
            assertTrue("all threads should complete successfully", 
                       threads[i].getSuccess());
        }
    }

    /**
     * Thread that executes a single test of the BaseException.
     */
    class BaseExceptionTester extends Thread {
        /**
         * Returns an indicator of whether the thread completed successfully.
         *
         * @return an indicator of whether the thread completed successfully
         */
        public boolean getSuccess() {
            return success;
        }

        /**
         * Indicator of whether the thread completed successfully.
         */
        private boolean success = true;

        /**
         * The main loop of the thread.
         */
        public void run() {
            BaseException exception = new BaseException();
            try {
                exception.initCause(new Exception());
                for (int i=0;i<CHAIN_LENGTH;i++){
                    exception = new BaseException("Exception "+new Integer(i).toString(),exception);
                }
                throw exception;
            } catch (final BaseException ex2){
                assertEquals(exception, ex2);
                for (int i=CHAIN_LENGTH;i>0;i--){
                    exception = (BaseException)CauseUtils.getCause(exception);
                }
                return;
            } catch (final Exception ex) {
                success = false;
            }
            fail("Exception should thrown");
        }
    }
}

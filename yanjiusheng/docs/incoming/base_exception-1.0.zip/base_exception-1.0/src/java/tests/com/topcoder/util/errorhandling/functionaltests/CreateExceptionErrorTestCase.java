package com.topcoder.util.errorhandling.functionaltests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * <p>Tests <code>initCause</code>, constructors.</p>
 *
 * <p>Copyright &copy; 2003, TopCoder, Inc. All rights reserved.</p>
 *
 * @author TCSDESIGNER
 * @version 1.0
 */
public class CreateExceptionErrorTestCase extends TestCase {

    public void testCreateBaseException() {
        final Throwable cause = new Exception();
        // these should not throw Exceptions themselves!
        new BaseException();
        new BaseException("cause");
        new BaseException("cause", cause);
        new BaseException(cause);
        new BaseException((String) null);
        new BaseException((Throwable) null);
        new BaseException(null, null);
        new BaseException(null, cause);
        new BaseException(null, new BaseException(cause));
    }

    public void testCreateBaseRuntimeException() {
        final Throwable cause = new Exception();
        // these should not throw Exceptions themselves!
        new BaseRuntimeException();
        new BaseRuntimeException("cause");
        new BaseRuntimeException("cause", cause);
        new BaseRuntimeException(cause);
        new BaseRuntimeException((String) null);
        new BaseRuntimeException((Throwable) null);
        new BaseRuntimeException(null, null);
        new BaseRuntimeException(null, cause);
        new BaseRuntimeException(null, new BaseRuntimeException(cause));
    }

    public void testCreateBaseError() {
        final Throwable cause = new Exception();
        // these should not throw Exceptions themselves!
        new BaseError();
        new BaseError("cause");
        new BaseError("cause", cause);
        new BaseError(cause);
        new BaseError((String) null);
        new BaseError((Throwable) null);
        new BaseError(null, null);
        new BaseError(null, cause);
        new BaseError(null, new BaseError(cause));
    }

    public void testIllegalArgs() {
        try {
            final BaseException be = new BaseException(new Exception());
            be.initCause(new Throwable());
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
            // good
        }
        try {
            final BaseRuntimeException bre =
                    new BaseRuntimeException(new Exception());
            bre.initCause(new Throwable());
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
            // good
        }
        try {
            final BaseError be = new BaseError(new Exception());
            be.initCause(new Throwable());
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
            // good
        }
        try {
            final BaseException be = new BaseException();
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            // good
        }
        try {
            final BaseRuntimeException bre = new BaseRuntimeException();
            bre.initCause(bre);
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            // good
        }
        try {
            final BaseError be = new BaseError();
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            // good
        }
    }

    public static Test suite() {
        return new TestSuite(CreateExceptionErrorTestCase.class);
    }
}

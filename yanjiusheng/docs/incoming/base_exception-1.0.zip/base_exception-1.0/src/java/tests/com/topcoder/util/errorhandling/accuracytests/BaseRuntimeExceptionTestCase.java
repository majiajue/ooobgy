/**
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.errorhandling.accuracytests;

import junit.framework.TestCase;
import com.topcoder.util.errorhandling.BaseRuntimeException;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * Tests the accuracy of the BaseRuntimeException class methods.
 *
 * @author adic
 * @version 1.0
 */
public class BaseRuntimeExceptionTestCase extends TestCase {

    /**
     * Set up environment.
     */
    public void setUp() {
    }

    /**
     * Cleanup environment.
     */
    public void tearDown() {
    }

    /**
     * Test constructors.
     */
    public void testConstructors() {
        new BaseRuntimeException();
        String s = null;
        new BaseRuntimeException(s);
        new BaseRuntimeException("aaaa");
        Throwable t = null;
        new BaseRuntimeException(t);
        new BaseRuntimeException(new Throwable());
        new BaseRuntimeException(null, null);
        new BaseRuntimeException("aaaa", null);
        new BaseRuntimeException(null, new Throwable());
        new BaseRuntimeException("aaaa", new Throwable());
    }

    /**
     * Test get/initCause.
     */
    public void testCause() {
        BaseRuntimeException be = new BaseRuntimeException();
        assertNull(be.getCause());

        // try set cause to the exception itself
        try {
            be.initCause(be);
            fail("should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException e) {
        }

        Throwable t = new Throwable();
        be.initCause(t);
        assertTrue(be.getCause() == t);

        // try init cause after it was already set
        try {
            be.initCause(t);
            fail("should have thrown IllegalStateException");
        } catch (IllegalStateException e) {
        }

        // try init cause after it was already set
        be = new BaseRuntimeException(t);
        try {
            be.initCause(t);
            fail("should have thrown IllegalStateException");
        } catch (IllegalStateException e) {
        }

        Throwable tt = null;
        be = new BaseRuntimeException(tt);
        assertNull(be.getCause());
        be = new BaseRuntimeException("aaaa", null);
        assertNull(be.getCause());
        be = new BaseRuntimeException(t);
        assertTrue(be.getCause() == t);
        be = new BaseRuntimeException("aaaa", t);
    }

    /**
     * Test getMessage.
     */
    public void testMessage() {
        BaseRuntimeException be = new BaseRuntimeException();
        assertNull(be.getMessage());
        String s = null;
        be = new BaseRuntimeException(s);
        assertNull(be.getMessage());
        be = new BaseRuntimeException(null, null);
        assertNull(be.getMessage());
        be = new BaseRuntimeException("aaaa");
        assertTrue(be.getMessage().equals("aaaa"));
        be = new BaseRuntimeException("aaaa", null);
        assertTrue(be.getMessage().equals("aaaa"));
    }

    /**
     * Test stack traces.
     */
    public void testStackTrace() {
        // build chain of exceptions;
        Exception e1 = new Exception("exception1");
        BaseRuntimeException e2 = new BaseRuntimeException("exception2", e1);
        BaseRuntimeException e3 = new BaseRuntimeException("exception3", e2);
        BaseRuntimeException e4 = new BaseRuntimeException("exception4", e3);
        BaseRuntimeException e5 = new BaseRuntimeException("exception5", e4);
        BaseRuntimeException be = new BaseRuntimeException("base", e5);

        be.printStackTrace();

        // print stack trace and check if it contains the names of the
        // chained exceptions
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        check(sw.toString());

        // print stack trace and check if it contains the names of the
        // chained exceptions
        ByteArrayOutputStream bs = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(bs);
        be.printStackTrace(ps);
        check(bs.toString());
    }

    /**
     * Check if the stacktrace prints at least the names of the chained
     * exceptions.
     *
     * @param s the stacktrace
     */
    private void check(String s) {
        assertTrue(s.indexOf("exception1") >= 0);
        assertTrue(s.indexOf("exception2") >= 0);
        assertTrue(s.indexOf("exception3") >= 0);
        assertTrue(s.indexOf("exception4") >= 0);
        assertTrue(s.indexOf("exception5") >= 0);
        assertTrue(s.indexOf("base") >= 0);
    }

}


/*
 * @(#)CheckGetMessageTest.java
 *
 * Copyright (c) 2003, TopCoder, Inc. All rights reserved
 */

package com.topcoder.util.errorhandling;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * Tests <code>BaseError</code>'s, <code>BaseException</code>'s and 
 * <code>BaseRuntimeException</code>'s <code>getMessage</code>.
 *
 * @author Sleeve
 * @version 1.0
 */
 
public class CheckGetMessageTest extends TestCase {

    /**
     * Checks to see that getMessage is returning proper messages
     * for BaseRuntimeException
     */
    public void testBaseRuntimeExceptionGetMessage() {
        final String className = "BaseRuntimeException";
        Throwable cause = new Exception();
        BaseRuntimeException b = new BaseRuntimeException(cause);
        BaseRuntimeException b2 = new BaseRuntimeException(b);
        
        checkMessage1(b2.getMessage(), className); 

        b = new BaseRuntimeException("test", cause);
        b2 = new BaseRuntimeException(b);
        
        checkMessage2(b2.getMessage(), className);
        
        b = new BaseRuntimeException("test", cause);
        b2 = new BaseRuntimeException("test2", b);
        
        assertEquals(b2.getMessage(), "test2, caused by test, caused by null");
        
        cause = new Exception("cause");
        b = new BaseRuntimeException("test", cause);
        b2 = new BaseRuntimeException("test2", b);
        
        assertEquals(b2.getMessage(), "test2, caused by test, caused by cause");
    }
    
    /**
     * Checks to see that getMessage is returning proper messages
     * for BaseException
     */
    public void testBaseExceptionGetMessage() {
        final String className = "BaseException";
        Throwable cause = new Exception();
        BaseException b = new BaseException(cause);
        BaseException b2 = new BaseException(b);
        
        checkMessage1(b2.getMessage(), className);

        b = new BaseException("test", cause);
        b2 = new BaseException(b);
        
        checkMessage2(b2.getMessage(), className);
        
        b = new BaseException("test", cause);
        b2 = new BaseException("test2", b);
        
        assertEquals(b2.getMessage(), "test2, caused by test, caused by null");
        
        cause = new Exception("cause");
        b = new BaseException("test", cause);
        b2 = new BaseException("test2", b);
        
        assertEquals(b2.getMessage(), "test2, caused by test, caused by cause");
    }
    
    /**
     * Checks to see that getMessage is returning proper messages
     * for BaseError
     */
    public void testBaseErrorGetMessage() {
        final String className = "BaseError";
        Throwable cause = new Exception();
        BaseError b = new BaseError(cause);
        BaseError b2 = new BaseError(b);
        
        checkMessage1(b2.getMessage(), className);

        b = new BaseError("test", cause);
        b2 = new BaseError(b);
        
        checkMessage2(b2.getMessage(), className);
        
        b = new BaseError("test", cause);
        b2 = new BaseError("test2", b);
        
        assertEquals(b2.getMessage(), "test2, caused by test, caused by null");
        
        cause = new Exception("cause");
        b = new BaseError("test", cause);
        b2 = new BaseError("test2", b);
        
        assertEquals(b2.getMessage(), "test2, caused by test, caused by cause");
    }
    
    /**
     * Checks the first type of message in each getMessage test case.
     */
    private void checkMessage1(final String message, String className) {
        assertNotNull(message);
        assertTrue(message.indexOf("java.lang.Exception") >= 0);
        assertTrue(message.indexOf("null") >= 0);
        assertTrue(message.indexOf(className) >= 0);
        assertTrue(message.indexOf(", caused by ") >= 0);
    }
    
    /**
     * Checks the second type of message in each getMessage test case.
     */
    private void checkMessage2(final String message, String className) {
        assertNotNull(message);
        assertTrue(message.indexOf("test") >= 0);
        assertTrue(message.indexOf("null") >= 0);
        assertTrue(message.indexOf(className) >= 0);
        assertTrue(message.indexOf(", caused by ") >= 0);
    }
    
    public static Test suite() {
        return new TestSuite(CheckGetMessageTest.class);
    }
}
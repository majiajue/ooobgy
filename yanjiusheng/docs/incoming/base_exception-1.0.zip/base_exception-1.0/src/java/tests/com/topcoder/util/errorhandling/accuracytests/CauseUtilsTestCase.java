/**
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.errorhandling.accuracytests;

import junit.framework.TestCase;
import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;
import com.topcoder.util.errorhandling.CauseUtils;

/**
 * Tests the accuracy of the CauseUtils class methods.
 *
 * @author adic
 * @version 1.0
 */
public class CauseUtilsTestCase extends TestCase {

    /**
     * Set up environment.
     */
    public void setUp() {
    }

    /**
     * Cleanup environment.
     */
    public void tearDown() {
    }

    /**
     * Test the getCause static method.
     */
    public void testGetCause() {
        assertNull(CauseUtils.getCause(new Throwable()));
        assertNull(CauseUtils.getCause(new BaseError()));
        assertNull(CauseUtils.getCause(new BaseException()));
        assertNull(CauseUtils.getCause(new BaseRuntimeException()));
        Throwable t = new Throwable();
        assertTrue(CauseUtils.getCause(new BaseError(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseException(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseRuntimeException(t)) == t);
        t = new BaseError();
        assertTrue(CauseUtils.getCause(new BaseError(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseException(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseRuntimeException(t)) == t);
        t = new BaseException();
        assertTrue(CauseUtils.getCause(new BaseError(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseException(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseRuntimeException(t)) == t);
        t = new BaseRuntimeException();
        assertTrue(CauseUtils.getCause(new BaseError(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseException(t)) == t);
        assertTrue(CauseUtils.getCause(new BaseRuntimeException(t)) == t);
    }

}


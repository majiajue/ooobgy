package com.topcoder.util.errorhandling.functionaltests;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * <p>Tests <code>printStackTrace()</code> methods.</p>
 *
 * <p>Copyright &copy; 2003, TopCoder, Inc. All rights reserved.</p>
 *
 * @author TCSDESIGNER
 * @version 1.0
 */
public class PrintStackTraceTestCase extends TestCase {

    public void testGetBaseExceptionMessage() {
        final Throwable cause = new Exception("Cause");
        final BaseException be = new BaseException("Message", cause);
        final BaseException be2 = new BaseException("Message2", be);

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        be2.printStackTrace(pw);
        checkStackTrace(sw.toString());

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        be2.printStackTrace(ps);
        checkStackTrace(baos.toString());

        // can't check the output, but shouldn't throw an exception:
        System.err.println("IGNORE THIS OUTPUT:");
        be2.printStackTrace();
    }

    public void testGetBaseRuntimeExceptionMessage() {
        final Throwable cause = new Exception("Cause");
        final BaseRuntimeException bre =
                new BaseRuntimeException("Message", cause);
        final BaseRuntimeException bre2 =
                new BaseRuntimeException("Message2", bre);

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        bre2.printStackTrace(pw);
        checkStackTrace(sw.toString());

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        bre2.printStackTrace(ps);
        checkStackTrace(baos.toString());

        // can't check the output, but shouldn't throw an exception:
        System.err.println("IGNORE THIS OUTPUT:");
        bre2.printStackTrace();
    }

    public void testGetBaseErrorMessage() {
        final Throwable cause = new Exception("Cause");
        final BaseError be = new BaseError("Message", cause);
        final BaseError be2 = new BaseError("Message2", be);

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        be2.printStackTrace(pw);
        checkStackTrace(sw.toString());

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        be2.printStackTrace(ps);
        checkStackTrace(baos.toString());

        // can't check the output, but shouldn't throw an exception:
        System.err.println("IGNORE THIS OUTPUT:");
        be2.printStackTrace();
    }

    private void checkStackTrace(final String stackTrace) {
        assertTrue(stackTrace.indexOf("Message") >= 0);
        assertTrue(stackTrace.indexOf("Message2") >= 0);
        assertTrue(stackTrace.indexOf("Cause") >= 0);
        assertTrue(stackTrace.indexOf("Caused by:") >= 0);
    }

    public void testIllegalArgs() {
        final BaseException be = new BaseException();
        try {
            be.printStackTrace((PrintStream) null);
            fail("Should have thrown a NullPointerException");
        } catch(NullPointerException npe) {
            // good
        }
        try {
            be.printStackTrace((PrintWriter) null);
            fail("Should have thrown a NullPointerException");
        } catch(NullPointerException npe) {
            // good
        }

        final BaseRuntimeException bre = new BaseRuntimeException();
        try {
            bre.printStackTrace((PrintStream) null);
            fail("Should have thrown a NullPointerException");
        } catch(NullPointerException npe) {
            // good
        }
        try {
            bre.printStackTrace((PrintWriter) null);
            fail("Should have thrown a NullPointerException");
        } catch(NullPointerException npe) {
            // good
        }

        final BaseError bErr = new BaseError();
        try {
            bErr.printStackTrace((PrintStream) null);
            fail("Should have thrown a NullPointerException");
        } catch(NullPointerException npe) {
            // good
        }
        try {
            bErr.printStackTrace((PrintWriter) null);
            fail("Should have thrown a NullPointerException");
        } catch(NullPointerException npe) {
            // good
        }
    }

    public static Test suite() {
        return new TestSuite(PrintStackTraceTestCase.class);
    }
}

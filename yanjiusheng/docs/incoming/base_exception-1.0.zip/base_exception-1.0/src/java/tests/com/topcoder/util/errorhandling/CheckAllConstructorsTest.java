/*
 * @(#)CheckAllConstructorsTest.java
 *
 * Copyright (c) 2003, TopCoder, Inc. All rights reserved
 */

package com.topcoder.util.errorhandling;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * Tests <code>BaseError</code>'s, <code>BaseException</code>'s and 
 * <code>BaseRuntimeException</code>'s <code>initCause</code>, and 
 * constructors.
 *
 * @author Sleeve
 * @version 1.0
 */
 
public class CheckAllConstructorsTest extends TestCase {
    
    /**
     * Tests <code>BaseRuntimeException</code>'s constructors. Should not
     * throw any exceptions here since this is not where we check for them.
     */
    public void createBaseRuntimeException() {
        final Throwable cause = new Exception();
        
        // test all BaseRuntimeException constructors
        new BaseRuntimeException();
        
        // constructor with message
        new BaseRuntimeException("message");
        new BaseRuntimeException((String) null);
        
        // constructor with message, cause
        new BaseRuntimeException("message", cause);
        new BaseRuntimeException("message2", null);
        new BaseRuntimeException(null, cause);
        new BaseRuntimeException(null, null);
        
        // constructor with cause
        new BaseRuntimeException(cause);
        new BaseRuntimeException((Throwable) null);
    }
    
    /**
     * Tests <code>BaseException</code>'s constructors. Should not
     * throw any exceptions here since this is not where we check for them.
     */
    public void createBaseException() {
        final Throwable cause = new Exception();
        
        // test all BaseException constructors
        new BaseException();
        
        // constructor with message
        new BaseException("message");
        new BaseException((String) null);
        
        // constructor with message, cause
        new BaseException("message", cause);
        new BaseException("message2", null);
        new BaseException(null, cause);
        new BaseException(null, null);
        
        // constructor with cause
        new BaseException(cause);
        new BaseException((Throwable) null);
    }
    
    /**
     * Tests <code>BaseError</code>'s constructors. Should not
     * throw any <code>Exception</code>s here since this is not where we check 
     * for them.
     */
    public void createBaseError() {
        final Throwable cause = new Exception();
        
        // test all BaseError constructors
        new BaseError();
        
        // constructor with message
        new BaseError("message");
        new BaseError((String) null);
        
        // constructor with message, cause
        new BaseError("message", cause);
        new BaseError("message2", null);
        new BaseError(null, cause);
        new BaseError(null, null);
        
        // constructor with cause
        new BaseError(cause);
        new BaseError((Throwable) null);
    }
    
    /**
     * Tests <code>initCause</code> to make sure that it throws the proper
     * <code>Exception</code>s
     */
    public void testInitCause() {
        
        /* test BaseRuntimeException, does it throw an IllegalArgumentException,
         * IllegalStateException and no exception at the right times?
         */
         
        try {
            final BaseRuntimeException b = 
                    new BaseRuntimeException(new Exception());
            
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseRuntimeException b = 
                    new BaseRuntimeException("message", new Exception());
            
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        // make sure no exceptions thrown here, can init cause here
        try {
            final BaseRuntimeException b = new BaseRuntimeException("message");
            
            b.initCause(new Throwable());
        } catch (IllegalStateException ise) {
            fail("Should not have thrown IllegalStateException, valid to init");
        }
        
        try {
            final BaseRuntimeException b = new BaseRuntimeException();
            
            b.initCause(new Throwable());
        } catch (IllegalStateException ise) {
            fail("Should not have thrown IllegalStateException, valid to init");
        }
        
        // make sure it throws an IllegalStateException if trying to init twice
        try {
            final BaseRuntimeException b = 
                    new BaseRuntimeException("message", new Exception());
            
            b.initCause(new Throwable());
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseRuntimeException b = new BaseRuntimeException();
            
            b.initCause(b);
            
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
        }
        
        /* test BaseException, does it throw an IllegalArgumentException,
         * IllegalStateException and no exception at the right times?
         */
        try {
            final BaseException b = new BaseException(new Exception());
            
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseException b = 
                    new BaseException("message", new Exception());
            
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        // make sure no exceptions thrown here, can init cause here
        try {
            final BaseException b = new BaseException("message");
            
            b.initCause(new Throwable());
        } catch (IllegalStateException ise) {
            fail("Should not have thrown IllegalStateException, valid to init");
        }
        
        try {
            final BaseException b = new BaseException();
            
            b.initCause(new Throwable());
        } catch (IllegalStateException ise) {
            fail("Should not have thrown IllegalStateException, valid to init");
        }
        
        // make sure it throws an IllegalStateException if trying to init twice
        try {
            final BaseException b = 
                    new BaseException("message", new Exception());
            
            b.initCause(new Throwable());
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseException b = 
                    new BaseException("message", new Exception());
            
            b.initCause(null);
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseException b = new BaseException();
            
            b.initCause(b);
            
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
        }
        
        /* test BaseError, does it throw an IllegalArgumentException,
         * IllegalStateException and no exception at the right times?
         */
        try {
            final BaseError b = new BaseError(new Exception());
            
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseError b = 
                    new BaseError("message", new Exception());
            
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        // make sure no exceptions thrown here, can init cause here
        try {
            final BaseError b = new BaseError("message");
            
            b.initCause(new Throwable());
        } catch (IllegalStateException ise) {
            fail("Should not have thrown IllegalStateException, valid to init");
        }
        
        try {
            final BaseError b = new BaseError();
            
            b.initCause(new Throwable());
        } catch (IllegalStateException ise) {
            fail("Should not have thrown IllegalStateException, valid to init");
        }
        
        // make sure it throws an IllegalStateException if trying to init twice
        try {
            final BaseError b = 
                    new BaseError("message", new Exception());
            
            b.initCause(new Throwable());
            b.initCause(new Throwable());
            
            fail("Should have thrown IllegalStateException");
        } catch (IllegalStateException ise) {
        }
        
        try {
            final BaseError b = new BaseError();
            
            b.initCause(b);
            
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
        }
    }
    
    public static Test suite() {
        return new TestSuite(CheckAllConstructorsTest.class);
    }
}
package com.topcoder.util.errorhandling.functionaltests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * <p>Tests <code>getMessage()</code>.</p>
 *
 * <p>Copyright &copy; 2003, TopCoder, Inc. All rights reserved.</p>
 *
 * @author TCSDESIGNER
 * @version 1.0
 */
public class GetMessageTestCase extends TestCase {

    public void testGetBaseExceptionMessage() {
        final Throwable cause = new Exception("Cause");
        final BaseException be = new BaseException("Message", cause);
        final BaseException be2 = new BaseException("Message2", be);
        checkMessage(be2.getMessage());
    }

    public void testGetBaseRuntimeExceptionMessage() {
        final Throwable cause = new Exception("Cause");
        final BaseRuntimeException bre =
                new BaseRuntimeException("Message", cause);
        final BaseRuntimeException bre2 =
                new BaseRuntimeException("Message2", bre);
        checkMessage(bre2.getMessage());
    }

    public void testGetBaseErrorMessage() {
        final Throwable cause = new Exception("Cause");
        final BaseError be = new BaseError("Message", cause);
        final BaseError be2 = new BaseError("Message2", be);
        checkMessage(be2.getMessage());
    }

    private void checkMessage(final String message) {
        assertNotNull(message);
        assertTrue(message.indexOf("Message") >= 0);
        assertTrue(message.indexOf("Message2") >= 0);
        assertTrue(message.indexOf("Cause") >= 0);
        assertTrue(message.indexOf(", caused by ") >= 0);
    }

    public static Test suite() {
        return new TestSuite(GetMessageTestCase.class);
    }
}

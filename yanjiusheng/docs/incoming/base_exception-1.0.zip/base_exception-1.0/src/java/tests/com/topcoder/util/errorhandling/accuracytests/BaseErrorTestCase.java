/**
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.errorhandling.accuracytests;

import junit.framework.TestCase;
import com.topcoder.util.errorhandling.BaseError;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * Tests the accuracy of the BaseError class methods.
 *
 * @author adic
 * @version 1.0
 */
public class BaseErrorTestCase extends TestCase {

    /**
     * Set up environment.
     */
    public void setUp() {
    }

    /**
     * Cleanup environment.
     */
    public void tearDown() {
    }

    /**
     * Test constructors.
     */
    public void testConstructors() {
        new BaseError();
        String s = null;
        new BaseError(s);
        new BaseError("aaaa");
        Throwable t = null;
        new BaseError(t);
        new BaseError(new Throwable());
        new BaseError(null, null);
        new BaseError("aaaa", null);
        new BaseError(null, new Throwable());
        new BaseError("aaaa", new Throwable());
    }

    /**
     * Test get/initCause.
     */
    public void testCause() {
        BaseError be = new BaseError();
        assertNull(be.getCause());

        // try set cause to the exception itself
        try {
            be.initCause(be);
            fail("should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException e) {
        }

        Throwable t = new Throwable();
        be.initCause(t);
        assertTrue(be.getCause() == t);

        // try init cause after it was already set
        try {
            be.initCause(t);
            fail("should have thrown IllegalStateException");
        } catch (IllegalStateException e) {
        }

        // try init cause after it was already set
        be = new BaseError(t);
        try {
            be.initCause(t);
            fail("should have thrown IllegalStateException");
        } catch (IllegalStateException e) {
        }

        Throwable tt = null;
        be = new BaseError(tt);
        assertNull(be.getCause());
        be = new BaseError("aaaa", null);
        assertNull(be.getCause());
        be = new BaseError(t);
        assertTrue(be.getCause() == t);
        be = new BaseError("aaaa", t);
    }

    /**
     * Test getMessage.
     */
    public void testMessage() {
        BaseError be = new BaseError();
        assertNull(be.getMessage());
        String s = null;
        be = new BaseError(s);
        assertNull(be.getMessage());
        be = new BaseError(null, null);
        assertNull(be.getMessage());
        be = new BaseError("aaaa");
        assertTrue(be.getMessage().equals("aaaa"));
        be = new BaseError("aaaa", null);
        assertTrue(be.getMessage().equals("aaaa"));
    }

    /**
     * Test stack traces.
     */
    public void testStackTrace() {
        // build chain of exceptions;
        Exception e1 = new Exception("exception1");
        BaseError e2 = new BaseError("exception2", e1);
        BaseError e3 = new BaseError("exception3", e2);
        BaseError e4 = new BaseError("exception4", e3);
        BaseError e5 = new BaseError("exception5", e4);
        BaseError be = new BaseError("base", e5);

        be.printStackTrace();

        // print stack trace and check if it contains the names of the
        // chained exceptions
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        check(sw.toString());

        // print stack trace and check if it contains the names of the
        // chained exceptions
        ByteArrayOutputStream bs = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(bs);
        be.printStackTrace(ps);
        check(bs.toString());
    }

    /**
     * Check if the stacktrace prints at least the names of the chained
     * exceptions.
     *
     * @param s the stacktrace
     */
    private void check(String s) {
        assertTrue(s.indexOf("exception1") >= 0);
        assertTrue(s.indexOf("exception2") >= 0);
        assertTrue(s.indexOf("exception3") >= 0);
        assertTrue(s.indexOf("exception4") >= 0);
        assertTrue(s.indexOf("exception5") >= 0);
        assertTrue(s.indexOf("base") >= 0);
    }

}


/*
 * @(#)CheckGetCauseTest.java
 *
 * Copyright (c) 2003, TopCoder, Inc. All rights reserved
 */

package com.topcoder.util.errorhandling;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;
import com.topcoder.util.errorhandling.CauseUtils;

/**
 * Tests <code>BaseError</code>'s, <code>BaseException</code>'s, 
 * <code>BaseRuntimeException</code>'s and <code>CauseUtils</code>'
 * <code>getCause</code>.
 *
 * @author Sleeve
 * @version 1.0
 */
 
public class CheckGetCauseTest extends TestCase {

    /**
     * Checks to see that getCause is returning proper causes and returning
     * proper references for BaseRuntimeException
     */
    public void testBaseRuntimeExceptionGetCause() {
        final Throwable cause = new Exception();
        
        // returning proper causes?
        BaseRuntimeException b = new BaseRuntimeException(cause);
        
        assertEquals("Cause not equal to cause set via constructor",
                     cause,
                     b.getCause());

        b = new BaseRuntimeException("message", cause);
        
        assertEquals("Cause not equal to cause set via constructor",
                     cause,
                     b.getCause());
             
        b = new BaseRuntimeException("message", null);
 
        assertNull("Cause not equal to cause set via constructor (null)",
                   b.getCause());
                   
        b = new BaseRuntimeException();
        
        assertNull("Cause was not set, should be null", b.getCause());     
        
        // returning proper causes if cause set by initCause?    
        Throwable t = b.initCause(cause);
        
        assertSame("initCause should return reference to b", b, t);
        assertEquals("Cause not equal to cause set via initCause",
                     cause,
                     b.getCause());

        b = new BaseRuntimeException();
        t = b.initCause(null);
        
        assertSame("initCause should return reference to b", b, t);
        assertNull("Cause not equal to cause set via initCause (null)",
                   b.getCause());       
    }
    
    /**
     * Checks to see that getCause is returning proper causes and returning
     * proper references for BaseException
     */   
    public void testBaseExceptionGetCause() {
        final Throwable cause = new Exception();
        
        // returning proper causes?
        BaseException b = new BaseException(cause);
        
        assertEquals("Cause not equal to cause set via constructor",
                     cause,
                     b.getCause());

        b = new BaseException("message", cause);
        
        assertEquals("Cause not equal to cause set via constructor",
                     cause,
                     b.getCause());
             
        b = new BaseException("message", null);
 
        assertNull("Cause not equal to cause set via constructor (null)",
                   b.getCause());
                   
        b = new BaseException();
        
        assertNull("Cause was not set, should be null", b.getCause());     
        
        // returning proper causes if cause set by initCause?    
        Throwable t = b.initCause(cause);
        
        assertSame("initCause should return reference to b", b, t);
        assertEquals("Cause not equal to cause set via initCause",
                     cause,
                     b.getCause());

        b = new BaseException();
        t = b.initCause(null);
        
        assertSame("initCause should return reference to b", b, t);
        assertNull("Cause not equal to cause set via initCause (null)",
                   b.getCause());       
    }
    
    /**
     * Checks to see that getCause is returning proper causes and returning
     * proper references for BaseError
     */  
    public void testBaseErrorCause() {
        final Throwable cause = new Exception();
        
        // returning proper causes?
        BaseError b = new BaseError(cause);
        
        assertEquals("Cause not equal to cause set via constructor",
                     cause,
                     b.getCause());

        b = new BaseError("message", cause);
        
        assertEquals("Cause not equal to cause set via constructor",
                     cause,
                     b.getCause());
             
        b = new BaseError("message", null);
 
        assertNull("Cause not equal to cause set via constructor (null)",
                   b.getCause());
                   
        b = new BaseError();
        
        assertNull("Cause was not set, should be null", b.getCause());     
        
        // returning proper causes if cause set by initCause?    
        Throwable t = b.initCause(cause);
        
        assertSame("initCause should return reference to b", b, t);
        assertEquals("Cause not equal to cause set via initCause",
                     cause,
                     b.getCause());

        b = new BaseError();
        t = b.initCause(null);
        
        assertSame("initCause should return reference to b", b, t);
        assertNull("Cause not equal to cause set via initCause (null)",
                   b.getCause());       
    }
    
    /**
     * Checks CauseUtils getCause method
     */
    public void testCauseUtils() {
        String s = null;
        final Throwable t1 = new Throwable(s);
        final BaseException be1 = new BaseException(t1);
        final BaseException be2 = new BaseException(be1);

        assertSame("CauseUtils returned wrong cause",
                   be1, CauseUtils.getCause(be2));
        assertSame("CauseUtils returned wrong cause",
                   t1, CauseUtils.getCause(be1));
        assertNull("CauseUtils should have returned null",
                   CauseUtils.getCause(t1));
    }
    
    public static Test suite() {
        return new TestSuite(CheckGetCauseTest.class);
    }
}
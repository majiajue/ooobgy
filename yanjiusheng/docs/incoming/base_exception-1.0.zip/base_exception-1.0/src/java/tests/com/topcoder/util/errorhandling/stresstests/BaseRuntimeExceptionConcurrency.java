package com.topcoder.util.errorhandling.stresstests;

import java.util.Hashtable;
import junit.framework.TestCase;
import com.topcoder.util.errorhandling.*;
import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * <p>This test launches a number of threads each accessing their own 
 * BaseRuntimeException.</p>
 *
 * @author aksonov
 * @version 1.0
 */
public class BaseRuntimeExceptionConcurrency extends AbstractBenchmark {

    private static final int CHAIN_LENGTH = 200;
    private static final int NUM_THREADS = 100;

    public BaseRuntimeExceptionConcurrency(){
        super("BaseRuntimeExceptionConcurrency");
    }

    /**
     * <p>This test launches a number of threads each creating long chain 
     * contained from BaseRuntimeException objects.</p>
     *
     * @exception InterruptedException if the test is interrupted
     */
    public void testBaseRuntimeExceptionConcurrency()  throws Exception{
        runBenchmark(10, "BaseRuntimeException");
    }

    public void runOnce() throws InterruptedException {
        BaseRuntimeExceptionTester[] threads = new BaseRuntimeExceptionTester[NUM_THREADS];
        for (int i = 0; i < threads.length; ++i) {
            threads[i] = new BaseRuntimeExceptionTester();
            threads[i].start();
        }
        for (int i = 0; i < threads.length; ++i) {
            threads[i].join();
            assertTrue("all threads should complete successfully", 
                       threads[i].getSuccess());
        }
    }

    /**
     * Thread that executes a single test of the BaseRuntimeException.
     */
    class BaseRuntimeExceptionTester extends Thread {
        /**
         * Returns an indicator of whether the thread completed successfully.
         *
         * @return an indicator of whether the thread completed successfully
         */
        public boolean getSuccess() {
            return success;
        }

        /**
         * Indicator of whether the thread completed successfully.
         */
        private boolean success = true;

        /**
         * The main loop of the thread.
         */
        public void run() {
            BaseRuntimeException exception = new BaseRuntimeException();
            try {
                exception.initCause(new Exception());
                for (int i=0;i<CHAIN_LENGTH;i++){
                    exception = new BaseRuntimeException("Exception "+new Integer(i).toString(),exception);
                }
                throw exception;
            } catch (final BaseRuntimeException ex2){
                assertEquals(exception, ex2);
                for (int i=CHAIN_LENGTH;i>0;i--){
                    exception = (BaseRuntimeException)CauseUtils.getCause(exception);
                }
                return;
            } catch (final Exception ex) {
                success = false;
            }
            fail("Exception should thrown");
        }
    }
}
